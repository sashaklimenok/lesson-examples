const compact = (arr) => {
  const result = [];
  for (let index = 0; index < arr.length; index++) {
    if (arr[index]) {
      result.push(arr[index]);
    }
  }

  return result;
};

const concat = (arr, ...rest) => {
  return [...arr, ...rest];
};

const join = (arr, separator) => {
  let result = "";
  for (let i = 0; i < arr.length; i++) {
    const element = arr[i];
    result += element + separator;
  }

  return result;
};

const reverse = (arr) => {
  const length = arr.length;
  for (let i = 0; i < arr.length / 2; i++) {
    const element = arr[i];
    arr[i] = arr[length - i - 1];
    arr[length - i - 1] = element;
  }
};

const data = [1, 2, 3, 4, 5];
reverse(data);

const truncate = (str, options) => {
  const separator = options.separator ?? "...";
  return str.slice(0, options.length) + separator;
};

const users = [
  { id: "1", name: "name", age: 18 },
  { id: "1", name: "name", age: 20 },
  { id: "1", name: "name", age: 30 },
  { id: "1", name: "name", age: 40 },
];

const result = users.filter((item) => item.age > 18);

const str = "lorem ipsum ;laskksdhjf kjkdhas k";
console.log(
  truncate(str, {
    length: 10,
  })
);

module.exports = {
  compact,
  concat,
  join,
};
